<?php
class komli extends Controller
{
    public function index()
    {
        $data["judul"] = "komli";
        $this->view("templates/header", $data);
        $this->view("komli/index");
        $this->view("templates/footer");
    }
}
?>