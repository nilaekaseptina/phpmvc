<?php
class siswa extends Controller
{
    public function index()
    {
        $data['judul'] = "siswa";
        $data['siswa'] =  $this->model("siswa_model")->getAllBlog();
        $this->view('templates/header', $data);
        $this->view('siswa/index', $data);
        $this->view('templates/footer');
    }
    public function detail($id)
    {
        $data['judul'] = "Detail Siswa";
        $data['siswa'] = $this->model("siswa_model")->getAllBlogId($id);
        $this->view('templates/header',$data);
        $this->view('siswa/detail',$data);
        $this->view('templates/footer');
    }
    public function tambah()
    {
        if( $this->model('siswa_model')->tambahData($_POST) > 0 ) {
            Flasher::setFlash('berhasil', 'ditambahkan', 'success');
            header('Location: ' . BASE_URL . '/siswa');
            exit;
        } else {
            Flasher::setFlash('gagal','dihapus','danger');
            header('Location: ' . BASE_URL . '/siswa');
            exit;
        }
    }
    public function hapus($id)
    {
        if( $this->model('siswa_model')->hapusDatasiswa($id) > 0 ) {
            Flasher::setFlash('berhasil', 'dihapus', 'success');
            header('Location: ' . BASE_URL . '/siswa');
            exit;
        } else {
            Flasher::setFlash('gagal', 'dihapus', 'danger');
            header('Location: ' . BASE_URL . '/siswa');
            exit;
        }
    }
}
