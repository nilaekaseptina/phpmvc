<?php
Class siswa_model 
{
    private $dbh;
    private $stmt;
    public function __construct()
    {
        //data source name
        $dsn = "mysql:host=127.0.0.1;dbname=phpmvc";
        try {
            $this->dbh = new PDO($dsn, 'root', '');
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
    public function getAllBlog()
    {
         $this->stmt = $this->dbh->prepare('SELECT * FROM siswa');
         $this->stmt->execute();
         return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllBlogId($id)
    {
        $this->stmt = $this->dbh->prepare("SELECT * FROM siswa WHERE id = $id");
        $this->stmt->execute();
        return $this->stmt->fetch(PDO::FETCH_ASSOC);

    }

    public function getId()
    {
        $this->stmt=$this->dbh->prepare('SELECT id FROM siswa order by id desc limit 1');
        $this->stmt->execute();
        return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function tambahData($data)
    {
        $getId = $this->getId();
        $id = $getId[0]['id'] + 1;
        $nama = $data['nama'];
        $jenis_kelamin = $data['jenis_kelamin'];
        $alamat = $data['alamat'];

        $query = "INSERT INTO siswa VALUES
        ('$id','$nama','$jenis_kelamin','$alamat');";

    $this->stmt=$this->dbh->prepare($query);
        $this->stmt->execute();
    }
    public function hapusDataSiswa($id)
    {
        $query = "DELETE FROM siswa WHERE id = $id";


        $this->stmt=$this->dbh->prepare($query);
        $this->stmt->execute();
        // $this->db->query($query);
        // $this->db->bind('id',$id);

        // $this->db->execute();

        // return $this->db->rowCount();
    }
        }
        
