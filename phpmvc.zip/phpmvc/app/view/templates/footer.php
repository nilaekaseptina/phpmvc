
<script src="<?= BASE_URL; ?>/js/bootstrap.bundle.min.js"></script>
</body>

</html>