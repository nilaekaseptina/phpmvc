<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h1>Selamat datang di SMKN 2 Trenggalek</h1>
            <!-- <p class="lead">Perkenalkan, saya <?= $data['nama']; ?></p> -->
            <hr class="my-4">
            <div class="card" style="max-width: 1990px;">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="img/gambar3.jpg" class="card-img" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Sambutan Kepala SMKN 2 Trenggalek</h5>
                            <p class="card-text">Assakamualaikum wr.wb
                                Selamat datang di website resmi SMKN 2 Trenggalek.
                            saya berharap Website ini dapat dijadikan wahana interaksi yang positif baik antar akademika maupun masyarakat pada umumnya
                        Sehingga kita bisa menjalankan silaturahmi di segala unsur</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <p>It Uses utility classes for typography and spacing to space content out within the larger container.</p> -->
            <!-- <a class="btn btn-primary btn-lg" href="#" role="button">Mulai</a> -->
        </div>
    </div>
</body>

</html>