<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial- scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Halaman <?= $data['judul']; ?></title>
    </head>
    <body>
        <div class="col-sm-8">
            <div class="card-body">
                <center>
                    <br>
                <h5 class="card-title">KOMPETENSI KEAHLIAN SMK NEGERI 2 TRENGGALEK</h5>
                </center>
                <br>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/akl.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">AKL</h5>
                                <p class="card-text">Akuntansi .</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/tb.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">TB</h5>
                                <p class="card-text">Tata Boga </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/dpib.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">DPIB</h5>
                                <p class="card-text">Desain Pemodelan dan Informasi Bangunan</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/kgsp.jpeg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">KGSP</h5>
                                <p class="card-text">Kontruksi Gedung Sanitasi dan Perawatan (KGSP)</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/rpl.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">RPL</h5>
                                <p class="card-text">Rekayasa Perangkat Lunak </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/tptu.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">TPTU</h5>
                                <p class="card-text">Teknik Pendinginan dan Tata Udara (TPTU)</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>